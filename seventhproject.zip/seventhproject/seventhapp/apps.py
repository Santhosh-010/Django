from django.apps import AppConfig


class SeventhappConfig(AppConfig):
    name = 'seventhapp'
