from django.apps import AppConfig


class FourthappConfig(AppConfig):
    name = 'fourthapp'
