from django.apps import AppConfig


class SixthappConfig(AppConfig):
    name = 'sixthapp'
