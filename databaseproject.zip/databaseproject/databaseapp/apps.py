from django.apps import AppConfig


class DatabaseappConfig(AppConfig):
    name = 'databaseapp'
